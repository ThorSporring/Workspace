import cv2

#haar face detection
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

#Capture the webcam
video_capture = cv2.VideoCapture(0)

while True:
    # Capture frame-by-frame
    ret, img = video_capture.read()
    
    #Convert image to gray-scale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    #detect faces
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    
    #Draw the faces
    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255),2)
    
    cv2.imshow('video',img)   

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# When everything is done, release the capture
video_capture.release()
cv2.destroyAllWindows()