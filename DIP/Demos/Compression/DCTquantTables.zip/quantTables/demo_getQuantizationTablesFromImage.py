#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr15, 2021

@author: Mads Dyrmann



This script extracts jpeg quantization tables from jpeg images
"""

from imageio import imwrite
import skimage
import numpy as np
import jpegio as jio



# %% Part 2
# Load image of Eileen Collins
f = skimage.data.astronaut()

qualities = list(reversed(range(1,101)))
e_rms_list = []
snr_rms_list = []
file_size_list = []


for q in qualities:
    # Write the image with a jpg-encoding
    # TIP: you can speed up saving and reading, by saving to a ram disk
    # in most GNU/Linux distributions (maybe also MacOS?) a ram disk is mounted in /dev/shm
    imwrite('/dev/shm/im.jpg', f, quality=q)


    jpeg = jio.read('/dev/shm/im.jpg')
    coef_array = jpeg.coef_arrays[0]  
    quant_tbl = jpeg.quant_tables[0]

    np.save('quantTable'+str(q), quant_tbl)